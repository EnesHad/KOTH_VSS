extends Node

@onready var player: AudioStreamPlayer = $AudioStreamPlayer

var cooldown = {}
const COOLDOWN_TIME = 1.5
var time_passed = 0.0

func _process(delta):
	time_passed += delta

func play_line(name: String):
	if not sounds.has(name):
		print("Announcer: missing line -> ", name)
		return

	# Cooldown
	if cooldown.has(name) and time_passed - cooldown[name] < COOLDOWN_TIME:
		return

	cooldown[name] = time_passed
	player.stream = sounds[name]
	player.play()

var sounds = {
	"king_of_the_hill": preload("res://audio/king_of_the_hill.ogg"),

	# Hill control
	"youre_in_the_hill": preload("res://audio/you're_in_the_hill.ogg"),
	"you_control_the_hill": preload("res://audio/you_control_the_hill.ogg"),
	"hill_retaken": preload("res://audio/hill_retaken.ogg"),
	"enemy_forces_have_the_hill": preload("res://audio/enemy_forces_have_the_hill.ogg"),
	"we_secured_the_hill": preload("res://audio/we_secured_the_hill.ogg"),
	"we_lost_the_hill": preload("res://audio/we_lost_the_hill.ogg"),
	"objective_compromised": preload("res://audio/objective_compromised.ogg"),
	"objective_under_threat": preload("res://audio/objective_under_threat.ogg"),

	# Contested
	"hill_contested": preload("res://audio/hill_contested.ogg"),
	"multiple_contacts_in_the_hill": preload("res://audio/multiple_contacts_in_the_hill.ogg"),

	# Timer
	"one_minute_remaining": preload("res://audio/one_minute_remaining.ogg"),

	# Losing badly
	"we_are_losing_this_fight": preload("res://audio/we_are_losing_this_fight.ogg"),

	# End match
	"objective_secured": preload("res://audio/objective_secured.ogg"),
	"we_failed_the_mission": preload("res://audio/we_failed_the_mission.ogg"),

	# Kills
	"double_kill": preload("res://audio/double_kill.ogg"),
	"triple_kill": preload("res://audio/triple_kill.ogg"),
	"enemy_squad_deleted": preload("res://audio/enemy_squad_deleted_from_existence.ogg"),
	"you_are_cooking": preload("res://audio/you_are_absolutely_cooking.ogg")
}
