extends Area3D

@onready var score_manager = $"/root/Level/ScoreManager"
@onready var announcer = $"/root/Level/Announcer"

var players_in_hill: Array = []
var owner_team = null
var last_state = ""

# TEAM OF LOCAL PLAYER
var my_team = 1  # CHANGE THIS PER PLAYER LATER

func _ready():
	connect("body_entered", Callable(self, "_on_enter"))
	connect("body_exited", Callable(self, "_on_exit"))

func _on_enter(body):
	if not body is Character:
		return

	if body not in players_in_hill:
		players_in_hill.append(body)
		score_manager.add_player(body.get_multiplayer_authority())
		announcer.play_line("youre_in_the_hill")

	_update_hill_state()

func _on_exit(body):
	if body in players_in_hill:
		players_in_hill.erase(body)
		score_manager.remove_player(body.get_multiplayer_authority())

	_update_hill_state()

func _update_hill_state():
	var count = players_in_hill.size()

	if count == 0:
		last_state = ""
		return

	# ----------------------
	# ONE PLAYER IN HILL
	# ----------------------
	if count == 1:
		var p = players_in_hill[0]
		var new_team = p.team

		# First capture
		if owner_team == null:
			owner_team = new_team
			if new_team == my_team:
				_play_once("we_secured_the_hill")
			_play_once("you_control_the_hill")
			return

		# Same team retakes
		if new_team == owner_team:
			if new_team == my_team:
				_play_once("we_secured_the_hill")
			_play_once("hill_retaken")
			_play_once("you_control_the_hill")
			return

		# Enemy flips hill
		if new_team != owner_team:
			if owner_team == my_team:
				_play_once("we_lost_the_hill")

			owner_team = new_team
			_play_once("enemy_forces_have_the_hill")
			_play_once("objective_compromised")
			return

	# ----------------------
	# MULTIPLE PLAYERS
	# ----------------------
	if count > 1:
		_play_once("hill_contested")
		_play_once("multiple_contacts_in_the_hill")

		var first_player = players_in_hill[0]
		if first_player.team == owner_team:
			_play_once("objective_under_threat")
		return

func _play_once(key: String):
	if last_state == key:
		return
	last_state = key
	announcer.play_line(key)
