extends Area3D

@onready var score_manager = $"/root/Level/ScoreManager"

var players_in_hill: Array = []
var owner_team = null

# Prevent repeated spam
var last_state = ""

func _ready():
	connect("body_entered", Callable(self, "_on_enter"))
	connect("body_exited", Callable(self, "_on_exit"))


func _on_enter(body):
	if not body is Character:
		return

	if body not in players_in_hill:
		players_in_hill.append(body)
		score_manager.add_player(body.get_multiplayer_authority())

	_update_hill_state()


func _on_exit(body):
	if body in players_in_hill:
		players_in_hill.erase(body)
		score_manager.remove_player(body.get_multiplayer_authority())

	_update_hill_state()


func _update_hill_state():
	var count = players_in_hill.size()

	if count == 0:
		last_state = ""
		return

	# ----------------------------------------------------
	# SINGLE PLAYER IN HILL
	# ----------------------------------------------------
	if count == 1:
		var p = players_in_hill[0]

		# first capture
		if owner_team == null:
			owner_team = p.team
			_play_once("you_control_the_hill")
			return

		# retake by same team
		if p.team == owner_team:
			_play_once("hill_retaken")
			_play_once("you_control_the_hill")
			return

		# enemy flips hill
		if p.team != owner_team:
			owner_team = p.team
			_play_once("enemy_forces_have_the_hill")
			_play_once("objective_compromised")
			return

	# ----------------------------------------------------
	# MULTIPLE PLAYERS - CONTESTED
	# ----------------------------------------------------
	if count > 1:
		_play_once("hill_contested")
		_play_once("multiple_contacts_in_the_hill")

		# someone threatens your control
		if players_in_hill[0].team == owner_team:
			_play_once("objective_under_threat")
		return


# ----------------------------------------------------
# PLAY VOICE LINE ONCE ONLY
# ----------------------------------------------------
func _play_once(key: String):
	if last_state == key:
		return

	last_state = key
	$"/root/Level/Announcer".play_line(key)
