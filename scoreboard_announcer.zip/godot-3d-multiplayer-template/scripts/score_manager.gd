extends Node

var hill_times = {}
var player_names = []
var players_in_hill = []
var player_teams = {} # {player id: "red" or "blue"}
signal times_updated

var time_left = 300
var played_one_minute = false

func _process(delta):
	# Add score for players in hill
	for id in players_in_hill:
		hill_times[id] += delta
		
	# Update scoreboard listeners
	emit_signal("times_updated")
	
	# Countdown logic
	time_left -= delta
	
	# Trigger announcer at 60 seconds (once)
	if int(time_left) == 60 and not played_one_minute:
		played_one_minute = true
		$"/root/Level/Announcer".play_line("one_minute_remaining")
		
func add_player(id):
	if id not in hill_times:
		hill_times[id] = 0.0
		
	# Get the player node from the scene
	var level = get_tree().get_current_scene()
	var player = level.get_node("PlayersContainer").get_node(str(id))
	
	# Store name
	if player:
		player_names[id] = player.nickname.text
		player_teams[id] = player.team
		
	if id not in players_in_hill:
		players_in_hill.append(id)
		
func remove_player(id):
	if id in players_in_hill:
		players_in_hill.erase(id)
		
func get_times():
	var result = []
	
	for id in hill_times.keys():
		result[id] = {
			"time": hill_times[id],
			"team": player_teams.get(id, "neutral")
		}
		
	return result
