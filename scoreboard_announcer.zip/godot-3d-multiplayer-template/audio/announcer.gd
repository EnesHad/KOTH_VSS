extends Node

@onready var player: AudioStreamPlayer = $Player

var sounds = {
	"defend_the_objective":          preload("res://audio/defend_the_objective.ogg"),
	"double_kill":                   preload("res://audio/double_kill.ogg"),
	"enemy_forces_have_the_hill":   preload("res://audio/enemy_forces_have_the_hill.ogg"),
	"enemy_squad_deleted":          preload("res://audio/enemy_squad_deleted_from_existence.ogg"),
	"hill_retaken":                 preload("res://audio/hill_retaken.ogg"),
	"hill_contested":               preload("res://audio/hill_contested.ogg"),
	"king_of_the_hill":             preload("res://audio/king_of_the_hill.ogg"),
	"multiple_contacts":            preload("res://audio/multiple_contacts_in_the_hill.ogg"),
	"objective_secured":            preload("res://audio/objective_secured.ogg"),
	"objective_under_threat":       preload("res://audio/objective_under_threat.ogg"),
	"objective_compromised":        preload("res://audio/objective_compromised.ogg"),
	"one_minute_remaining":         preload("res://audio/one_minute_remaining.ogg"),
	"secure_the_hill":              preload("res://audio/secure_the_hill.ogg"),
	"triple_kill":                  preload("res://audio/triple_kill.ogg"),
	"we_secured_the_hill":          preload("res://audio/we_secured_the_hill.ogg"),
	"we_lost_the_hill":             preload("res://audio/we_lost_the_hill.ogg"),
	"we_are_losing_this_fight":     preload("res://audio/we_are_losing_this_fight.ogg"),
	"we_failed_the_mission":        preload("res://audio/we_failed_the_mission.ogg"),
	"youre_in_the_hill":            preload("res://audio/you're_in_the_hill.ogg"),
	"you_are_cooking":              preload("res://audio/you_are_absolutely_cooking.ogg"),
	"you_control_the_hill":         preload("res://audio/you_control_the_hill.ogg")
}

func play_line(name: String):
	if sounds.has(name):
		player.stream = sounds[name]
		player.play()
	else:
		print("Announcer: missing line -> ", name)
