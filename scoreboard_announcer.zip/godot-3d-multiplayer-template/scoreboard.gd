extends Control

@onready var player_list = $VBoxContainer/PlayerList
@onready var score_manager = $"/root/Level/ScoreManager"

const TEAM_COLORS = {
	"blue": Color(0.2, 0.5, 1.0),
	"red": Color(1.0, 0.3, 0.3),
	"neutral": Color(1, 1, 1)
}

func _ready():
	score_manager.connect("times_updated", Callable(self, "_update_list"))

func _update_list():
	player_list.clear()
	var data = score_manager.get_times()

	for id in data.keys():
		var entry = data[id]
		var time = entry["time"]
		var name = entry["name"]
		var team = entry["team"]
		
		var label = Label.new()
		label.text = "%s : %1fs" % [name, time]
		label.modulate = TEAM_COLORS.get(team, Color.WHITE)
		
		player_list.add_child(label) 
